package com.java4u.springinitilizrdemo.springinitilizrdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringinitilizrDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringinitilizrDemoApplication.class, args);
	}
}
